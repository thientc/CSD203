# Define a class for the node in the linked list
class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class SinglyLinkedList:
    def __init__(self):
        self.head = None

    def add_to_head(self, x):
        new_node = Node(x)
        new_node.next = self.head
        self.head = new_node

