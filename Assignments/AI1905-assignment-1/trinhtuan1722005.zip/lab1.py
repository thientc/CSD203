class Node:
    def __init__(self, value):
        self.value = value
        self.next = None


class SinglyLinkedList:
    def __init__(self):
        self.head = None
        self.size = 0

    def addToHead(self, x):
        new_node = Node(x)
        new_node.next = self.head
        self.head = new_node
        self.size += 1

    def addToTail(self, x):
        new_node = Node(x)
        if self.head is None:
            self.head = new_node
        else:
            current = self.head
            while current.next:
                current = current.next
            current.next = new_node
        self.size += 1

    def addAfter(self, p, x):
        if p is None:
            print("Node p is None. Cannot add after.")
            return
        new_node = Node(x)
        new_node.next = p.next
        p.next = new_node
        self.size += 1

    def traverse(self):
        current = self.head
        while current:
            print(current.value, end=" -> ")
            current = current.next
        print("None")

    def deleteFromHead(self):
        if self.head is None:
            print("List is empty.")
            return None
        else:
            value = self.head.value
            self.head = self.head.next
            self.size -= 1
            return value

    def deleteFromTail(self):
        if self.head is None:
            print("List is empty.")
            return None
        if self.head.next is None:
            value = self.head.value
            self.head = None
            self.size -= 1
            return value
        current = self.head
        while current.next.next:
            current = current.next
        value = current.next.value
        current.next = None
        self.size -= 1
        return value

    def deleteAfter(self, p):
        if p is None or p.next is None:
            print("No node to delete after the given node.")
            return None
        value = p.next.value
        p.next = p.next.next
        self.size -= 1
        return value

    def delete(self, x):
        if x < 1 or x > self.size:
            print("Invalid position.")
            return None
        if x == 1:
            return self.deleteFromHead()
        curr = self.head
        for i in range(1, x - 1):
            curr = curr.next
        if curr.next is None:
            print("Position out of bounds.")
            return None
        value = curr.next.value
        curr.next = curr.next.next
        self.size -= 1
        return value


if __name__ == "__main__":
    linked_list = SinglyLinkedList()
    linked_list.addToHead(2)
    linked_list.addToTail(4)
    linked_list.addToTail(6)
    linked_list.addToTail(9)

    print("Danh sách gốc:")
    linked_list.traverse()

    p = linked_list.head.next
    linked_list.addAfter(p, 5)
    linked_list.traverse()

    print("Xóa phần tử đầu:", linked_list.deleteFromHead())
    linked_list.traverse()

    print("Xóa phần tử đuôi:", linked_list.deleteFromTail())
    linked_list.traverse()

    print("Xóa phần tử sau node có giá trị 5:", linked_list.deleteAfter(p))
    linked_list.traverse()

    print("Xóa phần tử tại vị trí 2:", linked_list.delete(2))
    linked_list.traverse()
