class Node:
    def __init__(self, value):
        self.value = value
        self.next = None
class Q1:
    def __init__(self):
        self.head = None
# 1. def addToHead(x) - add a node with value x at the head of a list.
    def addToHead(self, x):
        new_node = Node(x)
        new_node.next = self.head
        self.head = new_node
# 2. def addToTail(x) - add a node with value x at the tail of a list.
    def addToTail(self, x):
        new_node = Node(x)
        if self.head is None:
            self.head = new_node
            self.tail = new_node
        else:
            self.tail.next = new_node
            self.tail = new_node
# 2. def addToTail(x) - add a node with value x at the tail of a list.
    def addAfter(self, x, p):
        new_node = Node(x)
        if self.head is None:
            return

        current = self.head
        count = 0
        while current and count < p:
            current = current.next
            count += 1
        if current is None:
            return

        new_node.next = current.next
        current.next = new_node
# 4. def traverse() - traverse from head to tail and dislay info of all nodes in the list.
    def traverse(self):
        current = self.head
        while current:
            print(current.data, end = '')
            current = current.next
        print()
# 5. def deleteFromHead() - delete the head and return its info.
    def deleteFromHead(self):
        if not self.head:
            return None
        deleted_value = self.head.value
        self.head = self.head.next
        return deleted_value
# 6. def deleteFromTail() - delete the tail and return its info
    def deleteFromTail(self):
        if not self.head:
            return None
        if not self.head.next is None:
            return self.deleteFromHead()

        current = self.head
        while current.next.next:
            current = current.next
        deleted_value = current.next.value
        current.next = None
        return deleted_value
# 7. def deleteAter(p) - delete the node after the node p and return its info.
    def deleteAfter(self, p):
        current = self.head
        while current:
            if current.value == p and current.next:
                deleted_value = current.next.value
                current.next = current.next.next
                return deleted_value
            current = current.next
        return None
# 8. def del(x) - delele the first node whose info is equal to x
    def delete(self, x):
        current = self.head
        if current and current.value == x:
            self.head = current.next
            return current.value
        prev = None
        while current and current.value != x:
            prev = current
            current = current.next
        if current:
            prev.next = current.next
            return current.value
        return None
# 9. def search(x) - search and return the reference to the first node having info x.
    def search(self, x):
        current = self.head
        while current:
            if current.value == x:
                return current
            current = current.next
        return None
# 10. def count() - count and return number of nodes in the list.
    def count(self):
        current = self.head
        count = 0
        while current:
            count += 1
            current = current.next
        return count
# 11. def del(i) - delete an i-th node on the list. Besure that such a node exists.
    def delete(self, i):
        if i < 0:
            return
        current = self.head
        if i == 0:
            if current:
                self.head = current.next
                return current.value
            return None

        prev = None
        count = 0
        while current:
            if count == i:
                prev.next= current.next
                return current.value
            prev = current
            current = current.next
            count += 1
        return None
# 12. def sort() - sort the list by ascending order of info
    def sort(self):
        if not self.head or not self.head.next:
            return
        sorted_list = None
        current = self.head
        while current:
            next_node = current.next
            sorted_list = self.sortedInsert(sorted_list, current)
            current = next_node
        self.head = sorted_list
# 13. def del(p) - delete node p if it exists in the list
    def delete(self, p):
        if self.head is None:
            return None
        if self.head == p:
            self.head = self.head.next
            return

        current = self.head
        while current and current.next:
            if current.next == p:
                current.next = current.next.next
                return
            current = current.next
# 14. def toArray() - create and return array containing info of all nodes in the list.
    def toArray(self):
        array = []
        current = self.head
        while current:
            array.append(current.value)
            current = current.next
        return array
# 15. Merge two ordered singly linked lists of integers into one ordered list.
    def merge(self, other):
        merged_list = Q1()
        p1 = self.head
        p2 = other.head
        while p1 and p2:
            if p1.value <= p2.value:
                merged_list.addToTail(p1.value)
                p1 = p1.next
            else:
                merged_list.addToTail(p2.value)
                p2 = p2.next
        while p1:
            merged_list.addToTail(p1.value)
            p1 = p1.next
        while p2:
            merged_list.addToTail(p2.value)
            p2 = p2.next
        return merged_list
# 16. def addBefore(p, x) - add a node with value x before the node p.
    def addBefore(self, x, p):
        new_node = Node(x)
        if self.head is None:
            return
        if self.head == p:
            new_node.next = self.head
            self.head = new_node
            return

        current = self.head
        while current.next:
            if current.next == p:
                new_node.next = current.next
                current.next = new_node
                return
            current = current.next
        return None
# 17. Attach a singly linked list to the end of another singly linked list
    def attach(self, other):
        if not self.head:
            self.head = other.head
        else:
            current = self.head
            while current.next:
                current = current.next
            current.next = other.head
# 18. def max() - find and return the maximum value in the list.
    def max(self):
        if not self.head:
            return None
        max_value = self.head.value
        current = self.head.next
        while current:
            if current.value > max_value:
                max_value = current.value
            current = current.next
        return max_value
# 19. def min() - find and return the minimum value in the list.
    def min(self):
        if not self.head:
            return None
        min_value = self.head.value
        current = self.head.next
        while current:
            if current.value < min_value:
                min_value = current.value
            current = current.next
        return min_value
# 20. def sum() - return the sum of all values in the list
    def sum(self):
        total = 0
        current = self.head
        while current:
            total += current.value
            current = current.next
        return total
# 21. def avg() - return the average of all values in the list.
    def avg(self):
        count = self.count()
        return self.sum() / count if count > 0 else 0
