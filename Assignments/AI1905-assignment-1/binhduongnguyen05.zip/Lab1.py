class Node:
    def __init__(self, data):
        self.data = data
        self.next = None
class SinglyLinkedList:
    def __init__(self):
        self.head = None
    def addToHead(self, x):
        new_node = Node(x)
        new_node.next = self.head
        self.head = new_node
    def addToTail(self, x):
        new_node = Node(x)
        if self.head is None:
            self.head = new_node
        else:
            current = self.head
            while current.next:
                current = current.next
            current.next = new_node
    def addAfter(self, p, x):
        if p is None:
            print("The given node cannot be None")
            return
        new_node = Node(x)
        new_node.next = p.next
        p.next = new_node
    def traverse(self):
        current = self.head
        if current is None:
            print("List is empty")
        else:
            while current:
                print(current.data, end=" -> ")
                current = current.next
            print("None")
    def deleteFromHead(self):
        if self.head is None:
            print("List is empty, no head to delete.")
            return None
        deleted_value = self.head.data
        self.head = self.head.next
        return deleted_value


if __name__ == "__main__":
    linked_list = SinglyLinkedList()
    linked_list.addToHead(3)
    linked_list.addToTail(5)
    linked_list.addToTail(7)
    linked_list.addToHead(1)
    print("List after adding nodes:")
    linked_list.traverse()
    second_node = linked_list.head.next
    linked_list.addAfter(second_node, 9)
    print("\nList after adding 9 after the second node (3):")
    linked_list.traverse()
    print("\nDeleted head node with value:", linked_list.deleteFromHead())
    print("\nList after deleting the head:")
    linked_list.traverse()
