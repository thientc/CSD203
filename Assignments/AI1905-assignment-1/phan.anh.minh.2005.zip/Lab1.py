class Singly_linked_list:
    class Node:
        def __init__(self, data):
            self.data = data
            self.next = None

    def __init__(self):
        self.head = None
        self.size = 0

    def __len__(self):
        return self.size

    def addToHead(self, data):  #Thêm vào đầu
        node = self.Node(data)
        if self.head is None:
            self.head = node
        else:
            node.next = self.head
            self.head = node
        self.size += 1

    def addToTail(self, data):  #Thêm vào cuối
        node = self.Node(data)
        if self.head is None:
            self.head = node
        else:
            temp = self.head
            while temp.next:
                temp = temp.next
            temp.next = node
        self.size += 1

    def addAfter(self, p, data):  #Thm vào sau node thứ p(tính từ 0)
        if p < 0 or p > self.__len__() - 1:
            print(f'Does not have index {p}!')
        else:
            count = 0
            node = self.Node(data)
            temp = self.head
            while count != p:
                count += 1
                temp = temp.next
            node.next = temp.next
            temp.next = node
            self.size += 1

    def traverse(self):
        pre = None
        temp = self.head
        while temp:
            next_node = temp.next
            temp.next = pre
            pre = temp
            temp = next_node
        self.head = pre

    def deleteFromHead(self):
        if self.__len__() == 0:
            print('List empty!')
        else:
            self.head = self.head.next
        self.size -= 1

    def deleteFromTail(self):
        if self.__len__() == 0:
            print('List empty!')
        else:
            temp = self.head
            while temp.next.next:
                temp = temp.next
            temp.next = None
        self.size -= 1

    def deleteAter(self, p):
        if p < 0 or p >= self.__len__():
            print('Invalid index!')
        else:
            temp = self.head
            count = 0
            while count != p:
                count += 1
                temp = temp.next
            temp.next = temp.next.next
            self.size -= 1

    def count(self):
        return self.__len__()

    def search(self, value):
        temp = self.head
        count = 0
        while temp.next:
            if temp.data == value:
                print(f'Value at node {count}!')
                return
            temp = temp.next
            count += 1
        if temp.data == value:
            print(f'Value at node {count}!')
            return
        print('Value does not exist!')


    def max(self):
        temp = self.head
        max = temp.data
        while temp.next:
            if temp.data > max:
                max = temp.data
            temp = temp.next
        if temp.data > max:
            max = temp.data
        return max

    def min(self):
        temp = self.head
        min = temp.data
        while temp.next:
            if temp.data < min:
                min = temp.data
            temp = temp.next
        if temp.data < min:
            min = temp.data
        return min

    def del_value(self, value):
        temp = self.head
        if temp.data == value:
            self.deleteFromHead()
            self.size -= 1
        else:
            for i in range(self.__len__()):
                if temp.next.data == value:
                    temp.next = temp.next.next
                    self.size -= 1
                    return
                temp = temp.next
        print('Value does not exist!')

    def del_index(self, i): #Hàm đang lỗi
        if i == 0:
            self.deleteFromHead()
            self.size -= 1
            return
        elif i == self.__len__():
            self.deleteFromTail()
            self.size -= 1
            return
        else:
            temp = self.head
            count = 0
            while temp.next:
                if count == i-1:
                    temp.next = temp.next.next
                temp = temp.next
                count += 1
            return


    def __str__(self):
        temp = self.head
        while temp:
            print(temp.data)
            temp = temp.next


if __name__ == '__main__':
    lst = Singly_linked_list()
    lst.addToHead(6)
    lst.addToTail(333)
    lst.addToTail(4)
    lst.addToTail(77)
    lst.__str__()
