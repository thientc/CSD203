class Node:
    def __init__(self, element):
        self.element = element
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None
        self.size = 0

    def __count__(self):
        return self.size
    
    def addToHead(self, x):
        new_node = Node(x)
        new_node.next = self.head
        self.head = new_node
        self.size +=1

    def addToTail(self, x):
        new_node = Node(x)
        if not self.head:  
            self.head = new_node
            return
        
        current = self.head
        while current.next: 
            current = current.next
        current.next = new_node 
        self.size +=1

    def addAfter(self, p, x):
        current = self.head
        while current:
            if current.element == p:  # Find the node with value p
                new_node = Node(x)
                new_node.next = current.next
                current.next = new_node
                self.size +=1
                return
                
            current = current.next

    def traverse(self):
        current = self.head
        while current:
            print(current.element, end=' -> ')
            current = current.next
        print('None')

    def deleteFromhead(self):
        answer = self.head.element
        self.head = self.head.next
        self.size -= 1
        return answer

#   def deleteFromtail(self):

        if not self.head:  
            print("List is empty. Cannot delete from tail.")
            return None
        
        if not self.head.next:  
            value = self.head.element
            self.head = None  
            return value
        
        current = self.head
        while current.next and current.next:  
            current = current.next
        value = current.next.element
        current.next = None  
        return value
    
    def search(self, x):
        current = self.head
        while current:
            if current.element == x:
                return current  # Return the reference to the node
            current = current.next
        print(f"Node with value {x} not found.")
        return None  


linked = LinkedList()
linked.addToHead(5)
linked.addToTail(7)
linked.addAfter(5,6)
linked.search(7)
print(linked.__count__())
linked.traverse()
