class Node:
    def __init__(self, value):
        self.value = value
        self.next = None

class SinglyLinkedList:
    def __init__(self):
        self.head = None

    def addToHead(self, x):
        new_node = Node(x)
        new_node.next = self.head
        self.head = new_node

    def addToTail(self, x):
        new_node = Node(x)
        if not self.head:
            self.head = new_node
            return
        current = self.head
        while current.next:
            current = current.next
        current.next = new_node


    def traverse(self):
        current = self.head
        while current:
            print(current.value, end=" -> ")
            current = current.next
        print("None")

    def deleteFromHead(self):
        if not self.head:
            return None
        value = self.head.value
        self.head = self.head.next
        return value

    def deleteFromTail(self):
        if not self.head:
            return None
        if not self.head.next:
            value = self.head.value
            self.head = None
            return value
        current = self.head
        while current.next.next:
            current = current.next
        value = current.next.value
        current.next = None
        return value

    def deleteAfter(self, p):
        if not p or not p.next:
            return None
        value = p.next.value
        p.next = p.next.next
        return value

    def delete(self, x):
        if not self.head:
            return
        if self.head.value == x:
            self.head = self.head.next
            return
        current = self.head
        while current.next and current.next.value != x:
            current = current.next
        if current.next:
            current.next = current.next.next

    def search(self, x):
        current = self.head
        while current:
            if current.value == x:
                return current
            current = current.next
        return None

    def max(self):
        if not self.head:
            return None
        max_value = self.head.value
        current = self.head.next
        while current:
            if current.value > max_value:
                max_value = current.value
            current = current.next
        return max_value

    def min(self):
        if not self.head:
            return None
        min_value = self.head.value
        current = self.head.next
        while current:
            if current.value < min_value:
                min_value = current.value
            current = current.next
        return min_value

    def sum(self):
        total = 0
        current = self.head
        while current:
            total += current.value
            current = current.next
        return total

    def avg(self):
        total = 0
        count = 0
        current = self.head
        while current:
            total += current.value
            count += 1
            current = current.next
        return total / count if count > 0 else None

# TEST
mylist = SinglyLinkedList()
mylist.addToHead(5)
mylist.addToHead(4)
mylist.addToHead(3)
mylist.addToTail(7)
mylist.traverse()
print("Max:", mylist.max())
print("Min:", mylist.min())
print("Sum:", mylist.sum())
print("Avg:", mylist.avg())