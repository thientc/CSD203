class Node:
    def __init__(self, value):
        self.value = value
        self.next = None


class SingleLinkedList:
    def __init__(self):
        self.head = None

    def __repr__(self):
        if not self.head:
            return "Danh sách trống"  # Trả về chuỗi nếu danh sách trống

        nodes = []
        current = self.head
        while current:
            nodes.append(f"[{current.value}]")
            current = current.next

        return "Head -> " + " -> ".join(nodes) + " -> Tail"

    def add_To_Head(self, data):
        new_node = Node(data)
        new_node.next = self.head
        self.head = new_node

    def add_to_tail(self, data):
        new_node = Node(data)
        if not self.head:
            self.head = new_node
            return
        current = self.head
        while current.next:
            current = current.next
        current.next = new_node

    def addAfter(self, prev_node, data):
        if not prev_node:
            return
        current = self.head
        while current:
            if current.value == prev_node:
                new_node = Node(data)
                new_node.next = current.next
                current.next = new_node
                return
            current = current.next
        print(f'node {prev_node} ko có')

    def tranverse(self):
        pre = None
        current = self.head
        while current:
            next_node = current.next
            current.next = pre
            pre = current
            current = next_node
        self.head = pre

    def delete_from_head(self):
        if not self.head:
            return None
        delete_node = self.head
        self.head = self.head.next
        return delete_node.value

    def delete_from_tail(self):
        if not self.head:
            return None
        if not self.head.next:
            deleted_value = self.head.value
            self.head = None
            return deleted_value
        current = self.head
        while current.next.next:
            current = current.next
        delete_value = current.next.value
        current.next = None
        return delete_value

    def delete_after(self, prev_node, data):
        if not prev_node or not prev_node.next:
            return None
        delete_node = prev_node.next
        prev_node.next = delete_node.next
        return delete_node.value

    def search(self, value):
        current = self.head
        while current:
            if current.value == value:
                return value
            current = current.next
        return None

    def sort(self):
        if not self.head or not self.head.next:
            return

        swaped = True
        while swaped:
            swaped = False
            tmp = self.head
            while tmp.next:
                if tmp.value > tmp.next.value:
                    tmp.value, tmp.next.value = tmp.next.value, tmp.value
                    swaped = True
                tmp = tmp.next

    def count(self):
        current = self.head
        count = 0
        while current:
            count += 1
            current = current.next
        return count

    def to_Array(self):
        arr = []
        current = self.head
        while current:
            arr.append(current.value)
            current = current.next
        return arr

    def sum(self):
        total = 0
        current = self.head
        while current:
            total += current.value
            current = current.next
        return total

    def aver(self):
        current = self.head
        count = 0
        total = 0
        while current:
            count += 1
            total += current.value
            current = current.next
        return total / count


if __name__ == '__main__':
    my_linked_list = SingleLinkedList()
    my_linked_list.add_To_Head(1)
    my_linked_list.add_To_Head(2)
    my_linked_list.add_To_Head(3)
    my_linked_list.add_To_Head(4)
    print(my_linked_list.aver())
